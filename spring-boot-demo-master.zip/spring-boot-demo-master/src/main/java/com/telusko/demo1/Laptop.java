package com.telusko.demo1;

import org.springframework.stereotype.Component;

@Component
public class Laptop {

        public void compile(){
            System.out.println("compiling with 10 errors of 5 lines of code.");
        }

}
