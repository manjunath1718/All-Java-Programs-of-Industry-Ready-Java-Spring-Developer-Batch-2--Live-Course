package com.telusko.SpringDataJpaProject01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaProject01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaProject01Application.class, args);
	}

}
