package com.telusko.SpringDataJpaProject01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaProject01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
