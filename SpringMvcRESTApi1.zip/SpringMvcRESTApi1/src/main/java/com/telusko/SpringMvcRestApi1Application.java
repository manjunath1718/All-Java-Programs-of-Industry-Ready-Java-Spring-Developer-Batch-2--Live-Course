package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcRestApi1Application.class, args);
	}

}
