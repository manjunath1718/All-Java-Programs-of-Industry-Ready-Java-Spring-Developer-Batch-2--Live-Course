package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcCrmWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcCrmWebAppApplication.class, args);
	}

}
