package com.telusko.SpringJDBCApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
