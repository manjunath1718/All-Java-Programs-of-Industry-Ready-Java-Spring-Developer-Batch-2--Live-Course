package com.telusko.SpringJDBCApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbcApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcApiApplication.class, args);
	}

}
